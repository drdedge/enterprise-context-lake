"""Generate a markdown vault: frontmatter + body + [[wikilinks]]."""
import os, random, sys, json
n = int(sys.argv[1]); root = sys.argv[2]
rnd = random.Random(7)
topics = ["funds","counterparties","reporting","cashflow","crm","compliance","rfp","deals","valuation","tax","ops","data","legal","hr","it","esg","clo","lending","liquid","admin"]
types = ["fact","convention","preference","observation"]
status = ["approved","approved","approved","proposed","disputed","superseded"]
apps = ["crm","reporting","cashflow","rfp","ic","research"]
words = "allocation administrator vehicle covenant tranche waterfall mapping alias ledger custodian reconciliation notice drawdown distribution benchmark mandate sleeve feeder master blocker commitment".split()
os.makedirs(root, exist_ok=True)
index = []
for t in topics: os.makedirs(f"{root}/{t}", exist_ok=True)
for i in range(n):
    t = topics[i % len(topics)]; slug = f"{t}-{i:06d}"
    fm = {"name": slug, "description": f"{t} note {i} on {rnd.choice(words)} and {rnd.choice(words)}",
          "type": rnd.choice(types), "status": rnd.choice(status),
          "scope": rnd.choice(["firm","firm","project:p%d" % rnd.randrange(40),"skill:s%d" % rnd.randrange(30),"user:u%d" % rnd.randrange(2000)]),
          "topic": t, "apps": rnd.sample(apps, rnd.randint(0,3)), "valid_from": f"20{rnd.randint(19,26)}-{rnd.randint(1,12):02d}-01",
          "source": rnd.choice(["crm","admin-feed","reporting","analyst","agent-run"])}
    links = [f"{rnd.choice(topics)}-{rnd.randrange(n):06d}" for _ in range(rnd.randint(2,4))]
    body = " ".join(rnd.choice(words) for _ in range(110))
    code = f"ADM-{i:06d}"
    with open(f"{root}/{t}/{slug}.md","w") as f:
        f.write("---\n" + "".join(f"{k}: {json.dumps(v) if isinstance(v,list) else v}\n" for k,v in fm.items()) + "---\n\n")
        f.write(f"# {slug}\n\nAdministrator code {code}. {body}\n\nRelated: " + ", ".join(f"[[{l}]]" for l in links) + "\n")
    fm["links"] = links; fm["path"] = f"{t}/{slug}.md"; index.append(fm)
with open(f"{root}/_index.jsonl","w") as f:
    for r in index: f.write(json.dumps(r) + "\n")
