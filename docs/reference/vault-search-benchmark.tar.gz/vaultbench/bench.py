import subprocess, time, json, sys, os, statistics as st
root = sys.argv[1]; n = int(sys.argv[2])
def run(cmd, reps=7):
    xs=[]; out=b""
    for _ in range(reps):
        t=time.perf_counter(); out=subprocess.run(cmd, cwd=root, capture_output=True).stdout; xs.append((time.perf_counter()-t)*1000)
    return round(st.median(xs),1), len(out.splitlines())
res={"notes":n}
mid=f"{n//2:06d}"
res["rg_rare_fixed_whole_vault_ms"], res["rare_hits"] = run(["rg","-l","-F",f"ADM-{mid}","."])
res["rg_common_word_whole_vault_ms"], res["common_hits"] = run(["rg","-l","-w","custodian","."])
res["rg_metadata_line_whole_vault_ms"], res["meta_hits"] = run(["rg","-l","^status: disputed$","."])
res["rg_rare_in_one_topic_folder_ms"], _ = run(["rg","-l","-F",f"ADM-{mid}","funds"])
res["rg_backlinks_whole_vault_ms"], res["backlink_hits"] = run(["rg","-l","-F",f"[[funds-{(n//2)//20*20:06d}]]","."])
res["rg_spawn_overhead_ms"], _ = run(["rg","--version"])
# metadata index: load manifest once, then filter in memory
t=time.perf_counter(); idx=[json.loads(l) for l in open(f"{root}/_index.jsonl")]; res["manifest_load_ms"]=round((time.perf_counter()-t)*1000,1)
res["manifest_bytes"]=os.path.getsize(f"{root}/_index.jsonl")
t=time.perf_counter()
by={}; back={}
for r in idx:
    for k in ("topic","status","type","scope"): by.setdefault((k,r[k]),set()).add(r["name"])
    for a in r["apps"]: by.setdefault(("apps",a),set()).add(r["name"])
    for l in r["links"]: back.setdefault(l,set()).add(r["name"])
byname={r["name"]:r for r in idx}
res["build_inverted_index_ms"]=round((time.perf_counter()-t)*1000,1)
def q():
    return by[("topic","funds")] & by[("status","approved")] & by[("apps","reporting")] & by[("scope","firm")]
xs=[]
for _ in range(2000):
    t=time.perf_counter(); s=q(); xs.append((time.perf_counter()-t)*1000)
res["metadata_filter_in_memory_ms"]=round(st.median(xs),4); res["filter_hits"]=len(s)
# filter then grep only the subset (paths passed to rg)
paths=[byname[x]["path"] for x in s]
res["rg_within_filtered_subset_ms"], _ = run(["rg","-l","-w","custodian"]+paths[:5000])
res["subset_files"]=min(len(paths),5000)
# 2-hop neighbourhood from one note via in-memory links
start=f"funds-{(n//2)//20*20:06d}"
xs=[]
for _ in range(2000):
    t=time.perf_counter()
    h1=set(byname[start]["links"])|back.get(start,set()); h2=set()
    for x in h1:
        if x in byname: h2|=set(byname[x]["links"])
        h2|=back.get(x,set())
    xs.append((time.perf_counter()-t)*1000)
res["two_hop_neighbourhood_in_memory_ms"]=round(st.median(xs),4); res["two_hop_nodes"]=len(h1|h2)
# cold build of manifest by reading every file's frontmatter
t=time.perf_counter(); c=0
for d,_,fs in os.walk(root):
    for f in fs:
        if f.endswith(".md"):
            with open(os.path.join(d,f)) as fh:
                for line in fh:
                    if line.startswith("---") and c>=0: pass
                    if line=="\n": break
            c+=1
res["scan_all_frontmatter_ms"]=round((time.perf_counter()-t)*1000,1)
print(json.dumps(res))
